// Cloudflare Workers API Backend - video_to_ppt_serverless

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    // CORS Headers for API calls
    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, X-Slide-No, X-Timestamp, X-Seconds, X-Auth-Password",
    };

    // Handle OPTIONS request for CORS preflight
    if (method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    try {
      // 0. POST /api/admin/clear-r2 - 清空整個 R2 儲存桶的所有對象 (v2.07)
      if (path === "/api/admin/clear-r2" && method === "POST") {
        const authPassword = request.headers.get("X-Auth-Password");
        if (authPassword !== "666666") {
          return new Response("Unauthorized: Invalid password", { status: 401, headers: corsHeaders });
        }
        let listed = await env.MY_BUCKET.list();
        let deletedCount = 0;
        
        while (listed && listed.objects.length > 0) {
          const keys = listed.objects.map(o => o.key);
          await env.MY_BUCKET.delete(keys);
          deletedCount += keys.length;
          
          if (listed.truncated) {
            listed = await env.MY_BUCKET.list({ cursor: listed.cursor });
          } else {
            break;
          }
        }
        return Response.json({ success: true, deletedCount }, { headers: corsHeaders });
      }

      // 1. GET /api/tasks - 列出所有任務歷史
      if (path === "/api/tasks" && method === "GET") {
        const { results } = await env.DB.prepare(
          "SELECT * FROM tasks ORDER BY created_at DESC"
        ).all();
        return Response.json(results, { headers: corsHeaders });
      }

      // 2. POST /api/tasks - 建立新任務
      if (path === "/api/tasks" && method === "POST") {
        const body = await request.json();
        const { id, title, video_name, video_duration, status, github_run_id, github_run_url, execution_time_sec, token_hint } = body;
        
        if (!id || !title) {
          return new Response("Missing task ID or title", { status: 400, headers: corsHeaders });
        }

        const createdAt = new Date().toISOString();
        const taskStatus = status || "analyzing";
        
        // 1) 建立或覆蓋/更新任務 (v2.07)
        await env.DB.prepare(`
          INSERT INTO tasks (id, title, status, video_name, video_duration, github_run_id, github_run_url, execution_time_sec, token_hint, created_at) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          ON CONFLICT(id) DO UPDATE SET
            title = excluded.title,
            status = excluded.status,
            video_name = COALESCE(excluded.video_name, tasks.video_name),
            video_duration = COALESCE(excluded.video_duration, tasks.video_duration)
        `).bind(
          id, 
          title, 
          taskStatus, 
          video_name || null, 
          video_duration || null,
          github_run_id || null,
          github_run_url || null,
          execution_time_sec || null,
          token_hint || null,
          createdAt
        ).run();

        // 2) 若傳入投影片預載秒數清單，批次建立 D1 佔位紀錄
        if (Array.isArray(body.slides) && body.slides.length > 0) {
          // 先清空該任務舊的 slides 佔位紀錄，以防重複 (v2.07)
          await env.DB.prepare("DELETE FROM slides WHERE task_id = ?").bind(id).run();

          const statements = body.slides.map(slide => {
            return env.DB.prepare(
              "INSERT INTO slides (task_id, slide_no, timestamp, seconds, image_key, created_at) VALUES (?, ?, ?, ?, ?, ?)"
            ).bind(id, slide.slide_no, slide.timestamp, slide.seconds, "placeholder", createdAt);
          });
          await env.DB.batch(statements);
        }

        return Response.json({ success: true, id }, { headers: corsHeaders });
      }

      // 2.3. GET /api/yt-info - 解析 YouTube 影片直鏈與規格
      if (path.startsWith("/api/yt-info") && method === "GET") {
                const urlParam = new URL(request.url).searchParams.get("url");
        console.log("urlParam received:", urlParam);
        if (!urlParam) {
          return new Response("Missing url parameter", { status: 400, headers: corsHeaders });
        }

        let videoId = "";
        try {
          // 支援完整網址、簡短網址或直接 ID
          const parsedUrl = new URL(urlParam);
          if (parsedUrl.hostname.includes("youtu.be")) {
            videoId = parsedUrl.pathname.slice(1);
          } else {
            videoId = parsedUrl.searchParams.get("v") || "";
          }
        } catch (e) {
          videoId = urlParam; // 假設為直接 Video ID
        }
        
        // 僅保留英文、數字、底線與連字號，徹底剔除空白、\r、\n 或 URL 參數
        videoId = videoId.replace(/[^a-zA-Z0-9_-]/g, "");
        console.log("Parsed videoId:", videoId, "length:", videoId.length);

        if (videoId.length < 10 || videoId.length > 15) {
          return new Response(`Invalid YouTube URL or Video ID (debug length: ${videoId.length})`, { status: 400, headers: corsHeaders });
        }

        // 呼叫 YouTube Player API (使用 Android client 免簽名限制)
        const ytResponse = await fetch("https://www.youtube.com/youtubei/v1/player", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Android; Mobile; rv:19.0) Gecko/19.0 Firefox/19.0"
          },
          body: JSON.stringify({
            videoId: videoId,
            context: {
              client: {
                clientName: "ANDROID",
                clientVersion: "20.02.35",
                hl: "zh-TW",
                gl: "TW"
              }
            }
          })
        });

        if (!ytResponse.ok) {
          const errText = await ytResponse.text();
          console.error(`YouTube Player API error: Status ${ytResponse.status}, Body: ${errText}`);
          return new Response(`Failed to fetch from YouTube (HTTP ${ytResponse.status}): ${errText.substring(0, 100)}`, { status: 500, headers: corsHeaders });
        }

        const ytData = await ytResponse.json();
        const details = ytData.videoDetails || {};
        const title = details.title || "YouTube Video";
        const durationSec = parseInt(details.lengthSeconds || "0");

        const streamingData = ytData.streamingData || {};
        const formats = streamingData.formats || [];
        
        // 尋找 multiplexed mp4 影片流 (通常為 360p)
        let streamUrl = "";
        for (const format of formats) {
          if (format.url && format.mimeType && format.mimeType.includes("video/mp4")) {
            streamUrl = format.url;
            break;
          }
        }

        if (!streamUrl && formats.length > 0) {
          streamUrl = formats[0].url;
        }

        if (!streamUrl) {
          return new Response("No suitable video stream found", { status: 404, headers: corsHeaders });
        }

        return Response.json({
          videoId,
          title,
          durationSec,
          streamUrl
        }, { headers: corsHeaders });
      }

      // 2.7. GET /api/yt-proxy - CORS 轉發代理 YouTube 影片流 (支援 Range 請求)
      if (path.startsWith("/api/yt-proxy") && method === "GET") {
        const streamUrl = new URL(request.url).searchParams.get("url");
        if (!streamUrl) {
          return new Response("Missing url parameter", { status: 400, headers: corsHeaders });
        }

        const headers = new Headers();
        // 轉發瀏覽器的 Range 標頭以支援分段 Seek
        const rangeHeader = request.headers.get("Range");
        if (rangeHeader) {
          headers.set("Range", rangeHeader);
        }

        const response = await fetch(streamUrl, {
          method: "GET",
          headers: headers
        });

        const proxyHeaders = new Headers();
        for (const [key, val] of Object.entries(corsHeaders)) {
          proxyHeaders.set(key, val);
        }
        
        // 複製目標串流的標頭
        const copyHeaders = ["content-type", "content-length", "content-range", "accept-ranges"];
        for (const h of copyHeaders) {
          const val = response.headers.get(h);
          if (val) {
            proxyHeaders.set(h, val);
          }
        }

        // 若為下載模式，強制設定 Content-Disposition 使瀏覽器彈出存檔視窗
        const downloadParam = new URL(request.url).searchParams.get("download");
        if (downloadParam === "1") {
          proxyHeaders.set("Content-Disposition", 'attachment; filename="youtube_video.mp4"');
        }

        return new Response(response.body, {
          status: response.status,
          statusText: response.statusText,
          headers: proxyHeaders
        });
      }

      // 3. GET /api/tasks/:id - 取得特定任務詳情與投影片列表
      if (path.startsWith("/api/tasks/") && method === "GET" && !path.includes("/slides/") && !path.includes("/files/")) {
        const taskId = path.split("/")[3];
        
        // 查詢任務資訊
        const task = await env.DB.prepare("SELECT * FROM tasks WHERE id = ?").bind(taskId).first();
        if (!task) {
          return new Response("Task not found", { status: 404, headers: corsHeaders });
        }

        // 查詢投影片列表
        const { results: slides } = await env.DB.prepare(
          "SELECT * FROM slides WHERE task_id = ? ORDER BY slide_no ASC"
        ).bind(taskId).all();

        return Response.json({ ...task, slides }, { headers: corsHeaders });
      }

      // 4. DELETE /api/tasks/:id - 刪除特定任務與所有 R2 圖檔
      if (path.startsWith("/api/tasks/") && method === "DELETE") {
        const taskId = path.split("/")[3];

        // 查詢該任務底下所有的投影片
        const { results: slides } = await env.DB.prepare(
          "SELECT image_key FROM slides WHERE task_id = ?"
        ).bind(taskId).all();

        // 逐一刪除 R2 中的圖片
        for (const slide of slides) {
          try {
            await env.MY_BUCKET.delete(slide.image_key);
          } catch (err) {
            console.error(`Failed to delete R2 key ${slide.image_key}:`, err);
          }
        }

        // 刪除 D1 資料庫紀錄（外鍵 CASCADE 會自動刪除對應的 slides）
        await env.DB.prepare("DELETE FROM tasks WHERE id = ?").bind(taskId).run();

        return Response.json({ success: true }, { headers: corsHeaders });
      }

      // 4.5. PUT /api/tasks/:id - 更新任務屬性 (如狀態、標題)
      if (path.startsWith("/api/tasks/") && method === "PUT") {
        const taskId = path.split("/")[3];
        const body = await request.json();
        const { status, title, github_run_id, github_run_url, execution_time_sec, token_hint } = body;

        const updates = [];
        const bindings = [];

        if (status) {
          updates.push("status = ?");
          bindings.push(status);
        }
        if (title) {
          updates.push("title = ?");
          bindings.push(title);
        }
        if (github_run_id) {
          updates.push("github_run_id = ?");
          bindings.push(github_run_id);
        }
        if (github_run_url) {
          updates.push("github_run_url = ?");
          bindings.push(github_run_url);
        }
        if (execution_time_sec !== undefined) {
          updates.push("execution_time_sec = ?");
          bindings.push(execution_time_sec);
        }
        if (token_hint) {
          updates.push("token_hint = ?");
          bindings.push(token_hint);
        }

        if (updates.length > 0) {
          bindings.push(taskId);
          const query = `UPDATE tasks SET ${updates.join(", ")} WHERE id = ?`;
          await env.DB.prepare(query).bind(...bindings).run();
        }

        return Response.json({ success: true }, { headers: corsHeaders });
      }

      // 5. POST /api/tasks/:id/upload - 上傳單張投影片並寫入 R2 & D1
      if (path.startsWith("/api/tasks/") && path.endsWith("/upload") && method === "POST") {
        const taskId = path.split("/")[3];

        // 讀取自訂標頭獲取投影片元數據
        const slideNo = parseInt(request.headers.get("X-Slide-No"));
        const timestamp = request.headers.get("X-Timestamp") || "00:00:00";
        const seconds = parseFloat(request.headers.get("X-Seconds")) || 0;

        if (isNaN(slideNo)) {
          return new Response("Missing X-Slide-No header", { status: 400, headers: corsHeaders });
        }

        // 讀取圖片 binary blob
        const blob = await request.blob();
        if (blob.size === 0) {
          return new Response("Empty image body", { status: 400, headers: corsHeaders });
        }

        // R2 物件金鑰 (Key)
        const imageKey = `tasks/${taskId}/slide_${slideNo.toString().padStart(3, "0")}.png`;

        // 1) 寫入 R2 物件儲存桶
        await env.MY_BUCKET.put(imageKey, blob, {
          customMetadata: {
            taskId,
            slideNo: slideNo.toString(),
            timestamp,
          }
        });

        // 2) 寫入 D1 資料庫 (若為預載任務則更新，否則插入)
        const createdAt = new Date().toISOString();
        const existing = await env.DB.prepare(
          "SELECT count(*) as count FROM slides WHERE task_id = ? AND slide_no = ?"
        ).bind(taskId, slideNo).first();

        if (existing && existing.count > 0) {
          await env.DB.prepare(
            "UPDATE slides SET image_key = ?, created_at = ? WHERE task_id = ? AND slide_no = ?"
          ).bind(imageKey, createdAt, taskId, slideNo).run();
        } else {
          await env.DB.prepare(
            "INSERT INTO slides (task_id, slide_no, timestamp, seconds, image_key, created_at) VALUES (?, ?, ?, ?, ?, ?)"
          ).bind(taskId, slideNo, timestamp, seconds, imageKey, createdAt).run();
        }

        // 3) 若所有佔位符都已填滿，更新任務狀態為 'completed'
        const remaining = await env.DB.prepare(
          "SELECT id FROM slides WHERE task_id = ? AND image_key = 'placeholder'"
        ).bind(taskId).first();

        if (!remaining) {
          await env.DB.prepare(
            "UPDATE tasks SET status = 'completed' WHERE id = ?"
          ).bind(taskId).run();
        }

        return Response.json({ success: true, imageKey }, { headers: corsHeaders });
      }

      // 5.5. POST /api/tasks/:id/document - 上傳 PDF、PPTX、HTML 或 JSON 文件
      if (path.startsWith("/api/tasks/") && path.endsWith("/document") && method === "POST") {
        const taskId = path.split("/")[3];
        const type = request.headers.get("X-Doc-Type") || "pdf"; // 'pdf', 'pptx', 'html' or 'json'
        const filename = type === "pdf" ? "report.pdf" : (type === "pptx" ? "presentation.pptx" : (type === "html" ? "report.html" : "slides.json"));
        const contentType = type === "pdf" 
          ? "application/pdf" 
          : (type === "pptx" ? "application/vnd.openxmlformats-officedocument.presentationml.presentation" : (type === "html" ? "text/html; charset=utf-8" : "application/json; charset=utf-8"));

        const blob = await request.blob();
        if (blob.size === 0) {
          return new Response("Empty file body", { status: 400, headers: corsHeaders });
        }

        const docKey = `tasks/${taskId}/${filename}`;
        
        // 1) 寫入 R2
        await env.MY_BUCKET.put(docKey, blob, {
          customMetadata: { taskId, type },
          httpMetadata: { contentType }
        });

        // 2) 更新 D1 紀錄
        const column = type === "pdf" ? "pdf_key" : (type === "pptx" ? "pptx_key" : (type === "html" ? "html_key" : "json_key"));
        await env.DB.prepare(
          `UPDATE tasks SET ${column} = ? WHERE id = ?`
        ).bind(docKey, taskId).run();

        return Response.json({ success: true, docKey }, { headers: corsHeaders });
      }

      // 6. GET /api/tasks/:id/files/:filename - 從 R2 讀取通用檔案（投影片圖片、PDF、PPTX）回傳
      if (path.startsWith("/api/tasks/") && path.includes("/files/") && method === "GET") {
        const parts = path.split("/");
        const taskId = parts[3];
        const fileName = parts[5]; // slide_001.png, report.pdf, presentation.pptx
        
        const fileKey = `tasks/${taskId}/${fileName}`;

        // 從 R2 獲取物件
        const object = await env.MY_BUCKET.get(fileKey);
        if (!object) {
          return new Response("File not found in R2", { status: 404, headers: corsHeaders });
        }

        // 建立 Response
        const headers = new Headers();
        object.writeHttpMetadata(headers);
        headers.set("etag", object.httpEtag);
        
        // 動態設定 Content-Type 快取
        if (fileName.endsWith(".pdf")) {
          headers.set("Content-Type", "application/pdf");
        } else if (fileName.endsWith(".pptx")) {
          headers.set("Content-Type", "application/vnd.openxmlformats-officedocument.presentationml.presentation");
        } else if (fileName.endsWith(".html")) {
          headers.set("Content-Type", "text/html; charset=utf-8");
        } else if (fileName.endsWith(".json")) {
          headers.set("Content-Type", "application/json; charset=utf-8");
        } else {
          headers.set("Content-Type", "image/png");
        }
        
        // 若為 JSON 檔案，或請求參數指定 download=1，強制為下載附件 (v2.07)
        const requestUrlObj = new URL(request.url);
        if (requestUrlObj.searchParams.get("download") === "1" || fileName.endsWith(".json")) {
          headers.set("Content-Disposition", `attachment; filename="${encodeURIComponent(fileName)}"`);
        }
        
        headers.set("Cache-Control", "public, max-age=31536000"); // 快取 1 年
        
        // 合併 CORS 標頭
        for (const [key, value] of Object.entries(corsHeaders)) {
          headers.set(key, value);
        }

        return new Response(object.body, { headers });
      }

      // 若未匹配 any API 路由，交給 Cloudflare Workers Assets 託管 (靜態檔案)
      if (env.ASSETS) {
        return env.ASSETS.fetch(request);
      }

      return new Response("Not Found", { status: 404, headers: corsHeaders });
    } catch (err) {
      console.error(err);
      return new Response(err.message || "Internal Server Error", {
        status: 500,
        headers: corsHeaders,
      });
    }
  }
};
