-- D1 Database Schema for video_to_ppt_cloudflare

-- 任務表
CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    status TEXT NOT NULL,          -- 'analyzing', 'completed', 'failed'
    video_name TEXT,
    video_duration REAL,
    pdf_key TEXT,
    pptx_key TEXT,
    github_run_id TEXT,
    github_run_url TEXT,
    execution_time_sec REAL,
    token_hint TEXT,
    created_at TEXT NOT NULL
);

-- 投影片列表
CREATE TABLE IF NOT EXISTS slides (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id TEXT NOT NULL,
    slide_no INTEGER NOT NULL,
    timestamp TEXT NOT NULL,
    seconds REAL NOT NULL,
    image_key TEXT NOT NULL,       -- R2 object key
    created_at TEXT NOT NULL,
    FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE
);

-- 建立索引以優化查詢
CREATE INDEX IF NOT EXISTS idx_slides_task_id ON slides(task_id);
