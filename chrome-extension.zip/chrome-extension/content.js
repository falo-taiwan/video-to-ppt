/**
 * Video Slide Extractor - Content Script
 * 負責在 YouTube 頁面上操控 <video> 播放器，以及將視訊畫面繪製成高解析度影像回傳。
 */

console.log("[Video Slide Extractor] Content Script 已載入。");

// 監聽來自 Popup 的訊息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    const video = document.querySelector('video');

    if (request.action === "check_video") {
        if (video) {
            sendResponse({ 
                success: true, 
                title: document.title,
                duration: video.duration,
                width: video.videoWidth,
                height: video.videoHeight
            });
        } else {
            sendResponse({ success: false, error: "此網頁找不到 HTML5 影片播放器 (video element)。" });
        }
        return true;
    }

    if (request.action === "seek") {
        if (!video) {
            sendResponse({ success: false, error: "找不到播放器。" });
            return;
        }
        // 跳轉到指定秒數
        video.currentTime = parseFloat(request.time);
        
        // 如果影片暫停中，可以選擇保持暫停；如果是播放中，保持播放。
        // 為確保影格讀取穩定，在跳轉時通常會自動觸發影片更新
        sendResponse({ success: true, currentTime: video.currentTime });
        return true;
    }

    if (request.action === "capture") {
        if (!video) {
            sendResponse({ success: false, error: "找不到播放器。" });
            return;
        }

        try {
            // 獲取影片的實際像素解析度，而非 CSS 顯示尺寸
            const width = video.videoWidth;
            const height = video.videoHeight;

            if (width === 0 || height === 0) {
                sendResponse({ success: false, error: "影片解析度異常，請確認影片已載入播放。" });
                return;
            }

            const canvas = document.createElement('canvas');
            canvas.width = width;
            canvas.height = height;

            const ctx = canvas.getContext('2d');
            // 將 video 目前影格繪製於 Canvas 上
            ctx.drawImage(video, 0, 0, width, height);

            // 將畫布轉為 Base64 Data URL
            const dataUrl = canvas.toDataURL('image/png');

            sendResponse({ 
                success: true, 
                dataUrl: dataUrl, 
                width: width, 
                height: height 
            });
        } catch (err) {
            console.error("[Video Slide Extractor] 擷取影格失敗:", err);
            sendResponse({ success: false, error: `擷取影格失敗: ${err.message}` });
        }
        return true;
    }
});
