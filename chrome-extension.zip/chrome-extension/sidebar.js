/**
 * Video Slide Extractor - Sidebar Logic (側邊欄常駐版 - 記憶體安全優化版)
 * 負責匯入 JSON 軌跡檔、控制 YouTube 分頁跳轉、自動批次擷取影格、PNG 下載與 PDF 整合導出。
 * 採用 chrome.storage.local (本地資料庫) 儲存 Base64 大圖片，避免佔用 JS 堆疊記憶體以防崩潰。
 * 在開始擷取與 PDF 導出結束時，皆會主動執行資料庫與記憶體清理。
 */

let activeTabId = null;
let importedSlides = [];
let capturedStatus = {}; // 鍵為 slide.filename，值為 true (僅儲存擷取狀態，不儲存 Base64 大圖以省記憶體)
let isBatchRunning = false;

// UI DOM 元素
const statusBar = document.getElementById("status-bar");
const uploadPanel = document.getElementById("upload-panel");
const controlPanel = document.getElementById("control-panel");
const listCard = document.getElementById("list-card");
const fileInput = document.getElementById("file-input");
const videoTitle = document.getElementById("video-title");
const captureCount = document.getElementById("capture-count");
const totalCount = document.getElementById("total-count");
const btnBatch = document.getElementById("btn-batch");
const btnStop = document.getElementById("btn-stop");
const btnExportPdf = document.getElementById("btn-export-pdf");
const progressBarFill = document.getElementById("progress-bar-fill");
const progressArea = document.getElementById("progress-area");
const slideList = document.getElementById("slide-list");
const listStatus = document.getElementById("list-status");
const delayInput = document.getElementById("delay-input");

// 初始化：檢查當前 active tab 是否有播放器
document.addEventListener("DOMContentLoaded", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length === 0) {
            updateStatus("❌ 找不到作用中的 Chrome 分頁", false);
            return;
        }

        const activeTab = tabs[0];
        activeTabId = activeTab.id;

        // 確認是否為 YouTube 播放頁面
        if (!activeTab.url.includes("youtube.com/watch") && !activeTab.url.includes("youtube.com/live")) {
            updateStatus("⚠️ 請在 YouTube 影片或直播頁面打開此外掛", false);
            return;
        }

        // 送出偵測播放器訊息給 Content Script
        chrome.tabs.sendMessage(activeTabId, { action: "check_video" }, (response) => {
            if (chrome.runtime.lastError) {
                updateStatus("⚠️ 未偵測到 content.js。請重新整理 YouTube 頁面後再試一次！", false);
                console.error("Content script connection error:", chrome.runtime.lastError);
                return;
            }

            if (response && response.success) {
                updateStatus(`✅ 已成功連接播放器！影片尺寸: ${response.width}x${response.height}`, true);
            } else {
                const errMsg = (response && response.error) ? response.error : "未知錯誤";
                updateStatus(`⚠️ 連接失敗: ${errMsg}`, false);
            }
        });
    });
});

// 記憶體與資料庫清除函式 (開始與結束均要呼叫，防硬碟與 RAM 洩漏)
function clearAllStoredData() {
    return new Promise((resolve) => {
        // 清除整個 Chrome 擴充功能 Local 儲存資料庫
        chrome.storage.local.clear(() => {
            capturedStatus = {}; // 記憶體變數清空
            updateCaptureProgress();
            resolve();
        });
    });
}

// 監聽檔案上傳
fileInput.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async function(event) {
        try {
            const data = JSON.parse(event.target.result);
            if (!data.slides || !Array.isArray(data.slides)) {
                alert("JSON 格式不正確：找不到 slides 投影片清單！");
                return;
            }

            // 儲存資料
            importedSlides = data.slides;
            
            // 開始前徹底清空以前的快取大圖
            await clearAllStoredData();

            // 更新 UI
            videoTitle.textContent = data.title || "YouTube 影片";
            totalCount.textContent = importedSlides.length;
            captureCount.textContent = "0";
            listStatus.textContent = `共 ${importedSlides.length} 張投影片`;
            progressBarFill.style.width = "0%";
            btnExportPdf.disabled = true;

            // 顯示控制面板與清單
            uploadPanel.style.display = "none";
            controlPanel.style.display = "block";
            listCard.style.display = "flex";

            renderSlideList();
        } catch (err) {
            alert(`解析 JSON 失敗: ${err.message}`);
        }
    };
    reader.readAsText(file);
});

// 更新狀態列
function updateStatus(text, isConnected) {
    statusBar.textContent = text;
    statusBar.className = `status-bar ${isConnected ? "status-connected" : "status-disconnected"}`;
}

// 繪製投影片卡片清單
function renderSlideList() {
    slideList.innerHTML = "";
    importedSlides.forEach((slide, idx) => {
        const row = document.createElement("div");
        row.className = "slide-row";
        row.id = `slide-row-${idx}`;

        row.innerHTML = `
            <div class="slide-info">
                <span class="slide-no">No.${slide.slide_no}</span>
                <span class="slide-time">${slide.timestamp}</span>
                <span class="slide-status-marker" id="marker-${idx}">⚪</span>
            </div>
            <div class="slide-actions">
                <button class="row-btn" data-action="seek" data-index="${idx}">定位</button>
                <button class="row-btn" data-action="capture" data-index="${idx}">擷取</button>
            </div>
        `;
        slideList.appendChild(row);
    });

    // 綁定按鈕事件
    slideList.querySelectorAll(".row-btn").forEach(btn => {
        btn.addEventListener("click", (e) => {
            const action = e.target.getAttribute("data-action");
            const index = parseInt(e.target.getAttribute("data-index"));
            const slide = importedSlides[index];

            if (action === "seek") {
                seekTo(slide.seconds);
            } else if (action === "capture") {
                captureSingle(index);
            }
        });
    });
}

// 跳轉播放器位置
function seekTo(seconds) {
    if (!activeTabId) return;
    chrome.tabs.sendMessage(activeTabId, { action: "seek", time: seconds });
}

// 單張定位並擷取下載
async function captureSingle(index) {
    const slide = importedSlides[index];
    const marker = document.getElementById(`marker-${index}`);
    
    marker.textContent = "⏳";
    
    // 1. 定位
    seekTo(slide.seconds);
    
    // 2. 緩衝等待 (給予短暫延遲讓畫面更新)
    await new Promise(r => setTimeout(r, 800));

    // 3. 擷取
    chrome.tabs.sendMessage(activeTabId, { action: "capture" }, async (response) => {
        if (chrome.runtime.lastError || !response || !response.success) {
            marker.textContent = "❌";
            alert("擷取失敗！請確認 YouTube 影片分頁開啟且非最小化狀態。");
            return;
        }

        // 儲存大圖至 Chrome 本地 Local Storage (DB 儲存，不佔用堆疊記憶體)
        const imgKey = `slide_img_${slide.filename}`;
        const dimKey = `slide_dim_${slide.filename}`;
        chrome.storage.local.set({
            [imgKey]: response.dataUrl,
            [dimKey]: { width: response.width, height: response.height }
        }, async () => {
            capturedStatus[slide.filename] = true;
            marker.textContent = "✅";
            
            // 更新 UI 計數
            updateCaptureProgress();

            // 觸發 PNG 下載
            const safeTime = slide.timestamp.replace(/:/g, "-");
            const filename = `slide_${slide.slide_no.toString().padStart(3, '0')}_${safeTime}.png`;
            try {
                await downloadFile(response.dataUrl, filename);
            } catch (err) {
                console.error("下載 PNG 失敗:", err);
            }
        });
    });
}

// Chrome 下載 PNG 檔案
function downloadFile(dataUrl, filename) {
    return new Promise((resolve, reject) => {
        chrome.downloads.download({
            url: dataUrl,
            filename: filename,
            saveAs: false
        }, (downloadId) => {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            } else {
                resolve(downloadId);
            }
        });
    });
}

// 更新已擷取計數與按鈕狀態
function updateCaptureProgress() {
    const total = importedSlides.length;
    const current = Object.keys(capturedStatus).length;
    
    captureCount.textContent = current;
    
    const percentage = (current / total) * 100;
    progressBarFill.style.width = `${percentage}%`;

    // 只要有擷取到一張以上的投影片，即啟用導出 PDF
    btnExportPdf.disabled = (current === 0);
}

// 監聽批次按鈕
btnBatch.addEventListener("click", () => {
    if (isBatchRunning) return;
    startBatchCapture();
});

btnStop.addEventListener("click", () => {
    isBatchRunning = false;
});

// 啟動批次擷取佇列
async function startBatchCapture() {
    // 批次開始前清除舊有資料與記憶體快取
    await clearAllStoredData();

    isBatchRunning = true;
    btnBatch.style.display = "none";
    btnStop.style.display = "inline-flex";
    progressArea.style.display = "block";

    const delaySeconds = parseFloat(delayInput.value) || 1.5;
    const delayMs = delaySeconds * 1000;

    for (let i = 0; i < importedSlides.length; i++) {
        if (!isBatchRunning) {
            break;
        }

        const slide = importedSlides[i];
        const marker = document.getElementById(`marker-${i}`);
        marker.textContent = "⏳";
        
        // 滾動清單使當前處理行可見
        const row = document.getElementById(`slide-row-${i}`);
        if (row) {
            row.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }

        // 1. 定位 Seek
        seekTo(slide.seconds);

        // 2. 等待播放器讀取畫面
        await new Promise(r => setTimeout(r, delayMs));

        if (!isBatchRunning) break;

        // 3. 擷取影片畫面
        const response = await new Promise((resolve) => {
            chrome.tabs.sendMessage(activeTabId, { action: "capture" }, (res) => {
                if (chrome.runtime.lastError) {
                    resolve({ success: false, error: chrome.runtime.lastError.message });
                } else {
                    resolve(res);
                }
            });
        });

        if (response && response.success) {
            // 寫入 DB (chrome.storage.local)
            const imgKey = `slide_img_${slide.filename}`;
            const dimKey = `slide_dim_${slide.filename}`;
            await new Promise((resolve) => {
                chrome.storage.local.set({
                    [imgKey]: response.dataUrl,
                    [dimKey]: { width: response.width, height: response.height }
                }, () => {
                    capturedStatus[slide.filename] = true;
                    resolve();
                });
            });

            marker.textContent = "✅";

            // 4. 下載單張 PNG
            const safeTime = slide.timestamp.replace(/:/g, "-");
            const filename = `slide_${slide.slide_no.toString().padStart(3, '0')}_${safeTime}.png`;
            try {
                await downloadFile(response.dataUrl, filename);
            } catch (err) {
                console.error("下載 PNG 失敗:", err);
            }
        } else {
            marker.textContent = "❌";
            console.error("影格擷取失敗:", response ? response.error : "未知回應");
        }

        updateCaptureProgress();
    }

    // 批次完成或停止
    isBatchRunning = false;
    btnBatch.style.display = "inline-flex";
    btnStop.style.display = "none";
    progressArea.style.display = "none";
    
    const currentCount = Object.keys(capturedStatus).length;
    if (currentCount === importedSlides.length) {
        const outputMode = document.querySelector('input[name="output-mode"]:checked').value;
        if (outputMode === "img_pdf") {
            alert("🎉 批次高清擷取完成！即將自動整合導出 PDF 簡報...");
            setTimeout(() => {
                exportToPDF(true);
            }, 600);
        } else {
            alert("🎉 批次高清擷取下載完成！");
        }
    } else {
        alert("⚠️ 批次擷取中止或部分擷取完成。");
    }
}

// 導出 PDF 簡報
btnExportPdf.addEventListener("click", () => {
    exportToPDF(false);
});

async function exportToPDF(isAuto = false) {
    // 獲取選擇的解析度
    const resSelect = document.getElementById("pdf-res-select");
    const selectedRes = resSelect ? resSelect.value : "original";

    // 1. 遍歷獲取第一張已擷取的投影片尺寸，計算原始長寬比
    let firstSlideKey = null;
    let videoWidth = 1280;
    let videoHeight = 720;

    for (let slide of importedSlides) {
        const dimKey = `slide_dim_${slide.filename}`;
        const store = await new Promise(r => chrome.storage.local.get(dimKey, r));
        if (store && store[dimKey]) {
            firstSlideKey = slide;
            videoWidth = store[dimKey].width || 1280;
            videoHeight = store[dimKey].height || 720;
            break;
        }
    }

    if (!firstSlideKey) {
        alert("尚未擷取任何投影片，無法導出 PDF。");
        return;
    }

    // 依據解析度選擇，計算最終輸出的頁面尺寸
    const aspect = videoWidth / videoHeight;
    let targetWidth = videoWidth;
    let targetHeight = videoHeight;

    if (selectedRes === "1080") {
        targetHeight = 1080;
        targetWidth = Math.round(1080 * aspect);
    } else if (selectedRes === "720") {
        targetHeight = 720;
        targetWidth = Math.round(720 * aspect);
    }

    console.log(`[PDF Export] Mode: ${selectedRes}, Dimensions: ${targetWidth}x${targetHeight}`);

    // 初始化 UMD build 的 jsPDF 實體，設定預設尺寸
    const pdf = new jspdf.jsPDF({
        orientation: 'landscape',
        unit: 'px',
        format: [targetWidth, targetHeight]
    });

    let pageCount = 0;

    // 2. 依序從 DB 中異步取出大圖 Base64，並加入 PDF 頁面中
    for (let i = 0; i < importedSlides.length; i++) {
        const slide = importedSlides[i];
        const imgKey = `slide_img_${slide.filename}`;
        
        const store = await new Promise(r => chrome.storage.local.get(imgKey, r));
        const base64Data = store[imgKey];

        if (base64Data) {
            if (pageCount > 0) {
                // 直接新增一頁，自動繼承預設尺寸，避開 custom format 的 jsPDF 維度解析 error
                pdf.addPage();
            }

            // 寫入圖片，左上角 (0, 0)，寬高設為目標寬高
            pdf.addImage(base64Data, 'PNG', 0, 0, targetWidth, targetHeight);
            pageCount++;
        }
    }

    // 3. 導出並保存
    if (pageCount > 0) {
        const title = videoTitle.textContent.replace(/[\/\\?%*:|"<>. ]/g, "_");
        const pdfFilename = `slides_${title}.pdf`;
        
        pdf.save(pdfFilename);
        if (!isAuto) {
            alert(`🎉 PDF 導出成功！檔案已儲存為: ${pdfFilename}`);
        }

        // 結束後主動清空資料庫與記憶體變數，確保安全
        await clearAllStoredData();
    } else {
        alert("無法生成 PDF：無有效的投影片影像資料。");
    }
}
