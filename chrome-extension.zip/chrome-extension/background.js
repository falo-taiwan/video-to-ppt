/**
 * Video Slide Extractor - Background Service Worker
 * 設定當點擊外掛圖示時，主動開啟 Chrome 側邊欄 (Side Panel)。
 */

chrome.runtime.onInstalled.addListener(() => {
    // 開啟「點擊 action 圖示時打開側邊欄」的行為
    if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
        chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true })
            .then(() => {
                console.log("[Video Slide Extractor] 已設定點擊圖示開啟側邊欄。");
            })
            .catch((error) => {
                console.error("[Video Slide Extractor] 設定側邊欄行為失敗:", error);
            });
    }
});
